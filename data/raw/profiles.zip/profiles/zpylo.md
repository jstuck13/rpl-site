# zPylo

Captain, Fire Water Gang (Season 1 only). **Inactive for Season 2 — not on any Season 2 roster.**
This profile is institutional memory / career record more than a season preview. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: captain of Fire Water Gang (FWG), alongside Aowtty and Misnfrmd (both now on Lawson
  State for Season 2).
- Confirmed 2026-08-27 (Jacob): zPylo is not playing Season 2. Not in the Season 2 draft pool or
  on any roster.

## Season 1 stats (RPL_Master_Tracker)

22 games played. 28 goals, 6 assists, 30 saves, 100 shots, 9,659 total points.
Per game: 1.27 goals, 0.27 assists, 1.36 saves, 4.55 shots, 439.05 avg points.
Rank: Champion II — the rank ceiling of the league in Season 1 (before LLellum's Grand Champion I
arrived in Season 2). Season-end Player Value: $10,000, the model's hard ceiling.

League context: won Season MVP (highest Avg Points in RPL Season 1, 439.05 — ahead of Astro's
423.26). Highest shot volume in the league by a wide margin (4.55/game; next closest was Astro at
3.30). Highest goals/game (1.27) in the league. Lowest assist rate among regular starters
(0.27/game, essentially tied with Bl4ze Th3 MaN's 0.28 for last).

## What the numbers say

The most statistically dominant player RPL has produced to date, by a clear margin — Season MVP,
$10,000 value, rank ceiling of the league. But the shape of his production is distinct from
Astro's: zPylo scored more goals per game largely by shooting far more often (28 goals on 100
shots ≈ 28% conversion) rather than by finishing more efficiently — Astro shot less (89) and
converted more of it (≈35%). Read together: zPylo is the higher-volume, more ball-dominant
player; Astro the more efficient one. zPylo's assist rate is the lowest of any regular starter,
and his save involvement (1.36/game) is middling — a stat line that says shot-first, ball-hungry
striker more than a distributor or defensive anchor.

One more thing worth keeping on record: for all that individual output, Fire Water Gang did not
reach the Season 1 Final (999 vs. Lawson State) — the league's clearest statistical standout did
not get his team to the title series. Worth being careful with that framing since it's a 3-player
team result, not a solo failing, but it's a real thread in the story of his one RPL season.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Why he stepped away from Season 2 — done with RPL, timing/life circumstances, something else
  worth knowing if he ever returns?
- Any story behind FWG not reaching the Final despite his numbers — chemistry, matchup issues, a
  specific series that went wrong?
- Playstyle detail beyond the stat line — mechanical standout areas (aerials, flicks), aggressive
  first-man-in tendencies, a signature kickoff or rotation habit?
- Any notable rivalry or head-to-head worth recording, especially against Astro/LS given they
  were the league's top two Season 1 performers?

## Season log

- **2026-08-28**: Profile created as a historical/legacy record. Season 1 stats pulled from
  RPL_Master_Tracker via the Google Drive connector. Confirmed Inactive status for Season 2.
