# YoBoiHyperr

Season 1: captain of TTT. **Did not return for Season 2** — not on any Season 2 roster or in the
draft pool. This profile exists as a historical record so there's a basis to work from if he ever
comes back. See `claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: captain of TTT, alongside Spam God6450 and Ugadawg50. TTT was booted from the
  tournament partway through Season 1; schedule was rebalanced after its removal. Status in the
  tracker is Inactive, Player Value voided to N/A, raw stats retained.
- Per `/areas/rpl-season-1.md`'s recorded subbing history, he subbed for **Lawson State** at some
  point during Season 1 (his stats from that game weren't credited to either team, per the
  standard sub rule) — notable since that means TTT's own captain filled in for the team that
  went on to win the championship.
- Not in the Season 2 draft pool or on any Season 2 roster as of the 2026-08-28 draft.

## Season 1 stats (RPL_Master_Tracker)

7 games played (TTT's season ended early). 6 goals, 3 assists, 13 saves, 30 shots, 3,153 total
points.
Per game: 0.86 goals, 0.43 assists, 1.86 saves, 4.29 shots, **450.43 avg points** — numerically
the *highest* Avg Points of any player in the Season 1 dataset, ahead of even zPylo's 439.05
MVP-winning average. Not counted as MVP-eligible because of TTT's Inactive/voided status and the
small 7-game sample.

## What the numbers say

The most extreme version of the "TTT what-if" story — a higher per-game scoring pace than the
league's actual Season 1 MVP, over a 7-game sample that ended when his team got removed from
competition. High shot volume (4.29/game, 2nd only to zPylo's 4.55) paired with strong saves
(1.86/game) suggests real two-way involvement, but the sample is too short and the competitive
context too disrupted to treat this as equivalent to a full season's evidence. Worth keeping on
record precisely because the number is eye-catching, not because it should be taken at face
value.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Any read on whether the hot 7-game stretch reflects real skill or a small-sample/competition-
  quality artifact — same open question as Spam God6450's case, same team.
- Circumstances of subbing for Lawson State — friendly relationship with that roster, or just
  filling a gap?
- Why didn't he return for Season 2, and any context on TTT's removal from his side of it?
- Personality/reputation/leadership notes as TTT's captain.

## Season log

- **2026-08-28**: Profile created as a historical/legacy record. Season 1 stats pulled from
  RPL_Master_Tracker via the Google Drive connector. Not on a Season 2 roster.
