# TLBoryczka

Own Goal FC (S2), non-captain. Season 1: rostered on Lawson State under captain Astro. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on Lawson State (the eventual champions) alongside captain Astro and
  Blockymalrd.
- Season 2: bought by Bl4zeDaddy (Own Goal FC) for $12,591 — the 2nd-most expensive non-captain
  purchase of the entire draft, behind only Jart ($12,689).

## Season 1 stats (RPL_Master_Tracker)

30 games played — the most of any player in the league. 27 goals, 25 assists, 45 saves, 87 shots,
11,762 total points.
Per game: 0.90 goals, 0.83 assists (highest rate in the league), 1.50 saves, 2.90 shots, 392.07
avg points — 4th-highest in the league, behind only zPylo, Astro, and madlabs.
Rank: Diamond III (shared tier with DrewAJC only). Season-end Player Value: $8,346 (Base Value
$7,701, +$645 modifier, +21.5% Vs Rank Baseline) — the highest Player Value of any non-Champion-
tier player in Season 1, ahead of Bl4zeDaddy and well ahead of DrewAJC.
Won Golden Laces (most assists in the league, 25 total).

## What the numbers say

The most complete stat line in the league outside the top-3 Champion-tier players. Most games
played of anyone (durability/reliability across a full season), league-leading assist rate
(playmaking), and a top-4 Avg Points finish — scoring and setting up teammates at once, similar
in shape to madlabs' balanced profile. His +21.5% Vs Rank Baseline is the exact mirror of
DrewAJC's -21.5% in the same two-player Diamond III tier — he's the one pulling that tier's
average up. The $12,591 Own Goal FC paid for him tracks cleanly with a stat line this strong;
there's no mystery in this price the way there is with some other Season 2 buys.

## Season 2 — Match Day 1 (2026-09-02)

Series: Own Goal FC swept California Gurls, 3–0 (full recap: `claude/season2-day1-recap.md`).
TLBoryczka's line across the 3 games: 4 goals, 2 assists, 3 saves, 8 shots, 1,247 total score,
50% shooting, 4 demos inflicted, 1 taken. He scored in every game of the series (1, 2, 1) and was
the only Own Goal FC player with a recorded save in every game — the team's total was just 4
saves across 3 games, and 3 of those 4 were his.

Opened Season 2 exactly the way his Season 1 file predicted: the most complete two-way stat line
on the team, contributing goals, assists, and (essentially) all of the team's defensive stops
while Bl4zeDaddy played a pure-attack role beside him. One match day, but it's a clean match for
the "most complete player outside the Champion tier" read already on file from Season 1.

## Open — meta-game / meta-analysis (Jacob to fill in)

- On-field role — is he a true dual-threat, or does his assist rate reflect service to a
  particular finisher (e.g., Astro) that may not carry over to a new team context? Match Day 1's
  4G/2A on a new team (no more Astro to feed) is a small early data point toward "genuine
  dual-threat," but one series isn't conclusive.
- Mechanical strengths/weaknesses beyond the box score.
- Any read on how he and Bl4zeDaddy/Spam God6450 fit together as a new trio — Match Day 1 showed
  a clean division of labor (Bl4zeDaddy pure attack, TLBoryczka doing the two-way work) worth
  watching whether that holds.
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-08-28 (revision)**: Corrected pronouns (he/his) per Jacob — every RPL player to date has
  been male.
- **2026-09-02**: Added Season 2 Match Day 1 (4G/2A/3 saves in a 3-0 sweep of California Gurls),
  per Jacob's standing rule to fold match-day recap analysis into player profiles.
