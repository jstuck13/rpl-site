# Bl4zeDaddy

Captain, Own Goal FC (S2). Season 1: rostered on 999 under captain madlabs. In-game name "TTV
Bl4Ze D4ddy". See `claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on 999 alongside captain madlabs and DrewAJC.
- Season 2: stepped up to captain/manage his own team, Own Goal FC, auto-drafted at his own
  Player Value ($6,736).

## Season 1 stats (RPL_Master_Tracker)

26 games played. 20 goals, 14 assists, 39 saves, 70 shots, 9,465 total points.
Per game: 0.77 goals, 0.54 assists, 1.50 saves, 2.69 shots, 364.04 avg points.
Rank: Diamond II — a full tier below the Champion-rank group (zPylo, Astro, madlabs).
Season-end Player Value: $6,736 (Base Value $6,330, +$406 modifier, +13.5% Vs Rank Baseline).

## What the numbers say

The headline number here is the +13.5% Vs Rank Baseline modifier — the largest positive
rank-relative bump of any Season 1 returner on record so far. That stat specifically measures how
far above his own rank tier's average he performed, meaning Bl4zeDaddy wasn't just producing
decent raw numbers, he was meaningfully outperforming other Diamond II players. His saves rate
(1.50/game) is strong — 3rd-best in the league behind NO LIGHT (2.05) and roughly level with
Astro (1.52) and TLBoryczka (1.50) — paired with solid, not flashy, scoring (0.77 goals, 0.54
assists per game). Read together: a well-rounded two-way player whose rank (Diamond II) looks low
relative to how he actually performed against his peers — the profile of someone whose assigned
skill rank may understate his actual level.

## As a Season 2 manager

Own Goal FC's draft was built around spending to win now: he paired himself with TLBoryczka at
$12,591 — the 2nd-most expensive non-captain buy of the entire auction, behind only Jart — and
Spam God6450, a Season 1 TTT alum picked up cheap at $3,025. That's a real strategy read: pay top
dollar for a proven, high-output veteran (TLBoryczka led the league in assists in Season 1 — see
his profile), then hedge the rest of the cap on a low-cost flier out of a team that got booted
partway through Season 1 and hasn't had a real chance to prove anything since. OG closed the
auction with $1,391 left unspent, so this wasn't a maximal all-in like Lawson State's, but it's
clearly a "win now with proven talent" build rather than a rebuild.

## Season 2 — Match Day 1 (2026-09-02)

Series: Own Goal FC swept California Gurls, 3–0 (full recap: `claude/season2-day1-recap.md`).
Bl4zeDaddy's line across the 3 games: 3 goals, 2 assists, **0 saves**, 8 shots, 802 total score,
37.5% shooting, 1 demo inflicted, 0 taken. He scored in all three games — a perfectly consistent
1-1-1 line — while recording zero saves across the entire series.

That zero-saves number is the standout, and it reframes the "well-rounded two-way player" read
from his Season 1 profile above — at least for Match Day 1, this was a pure-attack role, with the
defensive/two-way work handled almost entirely by TLBoryczka (who logged 3 of the team's 4 total
saves). Whether that's a deliberate Season 2 role change (captain plays the front, TLBoryczka
covers the back) or just how this particular blowout series played out is an open question — the
Season 1 saves rate (1.50/game, 3rd-best in the league) suggests he's capable of two-way play, so
a 0-save series is a real change in shape worth watching over more match days.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Does "outperforming his rank" match what people who've played with/against him would say, or is
  there a simpler explanation (e.g., played a lot of games against weaker lineups)?
- On-field role and mechanical strengths — the Season 1 save numbers suggest strong defensive
  positioning, but Match Day 1 (0 saves, pure scoring) looks like a different role entirely as
  captain. Worth confirming with Jacob whether this is a deliberate shift.
- As a first-time manager in Season 2, what's the vision for Own Goal FC with TLBoryczka and Spam
  God6450 — proven-core-plus-project, or something else? Match Day 1 suggests a clean division of
  labor (Bl4zeDaddy attacks, TLBoryczka does the two-way work) — worth asking if that's by design.
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-08-28 (revision)**: Removed a reference to Season 1 Final ballchasing-replay data at
  Jacob's request — those replays were only used to test the replay-ingestion system and aren't
  meaningful record. Added explicit manager/draft-strategy commentary for Season 2.
- **2026-09-02**: Added Season 2 Match Day 1 (3G/2A/0 saves, a goal in every game, in a 3-0 sweep
  of California Gurls), per Jacob's standing rule to fold match-day recap analysis into player
  profiles.
- **2026-09-02 (correction)**: Fixed a leftover "her profile" pronoun reference to TLBoryczka
  (should be "his profile") — every RPL player is he/him per the Pronouns section in
  `claude/player-profiles-about.md`.
