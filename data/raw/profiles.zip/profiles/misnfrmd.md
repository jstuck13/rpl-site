# Misnfrmd

Lawson State (S2), non-captain. Season 1: rostered on Fire Water Gang under captain zPylo. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on Fire Water Gang alongside captain zPylo and Aowtty.
- Season 2: bought by Astro (Lawson State) for **$10,317** — more than Astro's own captain value,
  and the single most-discussed price of the Season 2 auction (see below).

## Season 1 stats (RPL_Master_Tracker)

22 games played. 14 goals, 5 assists, 16 saves, 43 shots, 4,836 total points.
Per game: 0.64 goals, 0.23 assists, 0.73 saves, 1.95 shots, 219.82 avg points — the **lowest**
full-season Avg Points of any Active-status Season 1 player now on a Season 2 roster.
Rank: Diamond II (shared tier with Bl4zeDaddy and Blockymalrd). Season-end Player Value: $1,000 —
Base Value floor-clamped (raw formula would have landed near $97, per
`claude/player-value-engine-design.md`'s verification notes), Vs Rank Baseline -30.1% ($-903
modifier), the largest negative modifier of any player in the dataset.

## What the numbers say

By the numbers, Misnfrmd's Season 1 was the weakest of any player returning for Season 2 —
lowest points average in the returning pool, worst rank-relative performance in the whole
league, and the only returner whose value hit the model's absolute $1,000 floor. That makes
Astro's $10,317 bid for him — more than 10x his season-end model value — the largest gap between
price paid and model-driven value anywhere in the Season 2 draft, LLellum's exempted case aside.
This isn't a case where the stats offer a supporting explanation; whatever justified that price
lives entirely in the meta-game layer, not the box score.

## Open — meta-game / meta-analysis (Jacob to fill in)

- **The central question**: why did Astro pay $10,317 for Misnfrmd? Chemistry/history between
  them, a specific role (support/boost-discipline/rotation) that a goals-and-assists model
  doesn't capture, a genuine belief in a bounce-back, or a bidding war that got away from Astro?
- Has something changed in his game since Season 1 that wouldn't show up in old stats?
- On-field role and mechanical notes.
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
