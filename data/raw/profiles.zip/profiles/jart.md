# Jart

California Gurls (S2), non-captain. New to RPL — no Season 1 history. See
`claude/player-profiles-about.md` for methodology.

## Identity

- New to RPL for Season 2. Bought by F1yTe Bacon (California Gurls) for $12,689 at auction — the
  single most expensive non-captain purchase of the entire Season 2 draft (edging out
  TLBoryczka's $12,591).

## Season 2 — Match Day 1 (2026-09-02)

Series: California Gurls lost to Own Goal FC, 0–3 (full recap: `claude/season2-day1-recap.md`).
Jart's line across the 3 games: 2 goals, 2 assists, 0 saves, 8 shots, 650 total score, 25%
shooting, 0 demos inflicted, 1 taken.

A modest opening series relative to the price tag — he did contribute in every game (1 goal, then
1 goal, then 1 assist), but 650 total score was the lowest of California Gurls' three players who
played, and well behind F1yTe Bacon's 1,124. It's the first data point against the league's
priciest non-captain buy, but one match day (and one sweep loss for the whole team) isn't enough
to call the price a reach — worth tracking against a larger sample and against opponents other
than a very strong Own Goal FC.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Why the record $12,689 price at auction — a specific read on his game from those in the draft
  room, name recognition, or bidding-war dynamics? Match Day 1's modest line doesn't yet explain
  the price either way.
- On-field role and mechanical notes.
- Personality/reputation notes worth recording.

## Season log

- **2026-09-02**: Profile created from Match Day 1 data (2G/2A/0 saves, lowest total score of
  California Gurls' three participants, in an 0-3 series loss to Own Goal FC) — first game logged
  for a player who had no prior profile. Per Jacob's standing rule to fold match-day recap
  analysis into player profiles as recaps are produced.
