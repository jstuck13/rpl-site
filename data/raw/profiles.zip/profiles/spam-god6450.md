# Spam God6450

Own Goal FC (S2), non-captain. Season 1: rostered on TTT under captain YoBoiHyperr. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on TTT, the team that was booted from the tournament partway through the
  season (see `claude/rpl-operating-philosophy.md`'s note on the general pattern of RPL
  decisions being revisited, and personal-memory record of the TTT removal). TTT is marked
  Inactive in the tracker; Player Value is voided to N/A for its players, raw stats retained.
- Season 2: bought by Bl4zeDaddy (Own Goal FC) for $3,025 — a low-cost pickup out of a team that
  never finished its season.

## Season 1 stats (RPL_Master_Tracker)

7 games played (TTT's season ended early). 8 goals, 3 assists, 11 saves, 14 shots, 2,882 total
points.
Per game: 1.14 goals, 0.43 assists, 1.57 saves, 2.00 shots, **411.71 avg points**.
Status: Inactive (TTT), Player Value officially N/A/voided — not a counted Season 1 value despite
the strong rate stats.

## What the numbers say

Genuinely one of the most interesting small-sample lines on record: 411.71 avg points over 7
games would rank 3rd in the entire league (between Astro's 423.26 and madlabs' 399.85) if it were
a full, counted season. But it's a 7-game sample from a team that got removed from competition
before it could be tested at real volume, and the tracker treats it as voided rather than a real
Player Value — so this can't be weighted the same as a full season's evidence. Worth tracking
whether Season 2 confirms or complicates this read.

## Season 2 — Match Day 1 (2026-09-02)

Series: Own Goal FC swept California Gurls, 3–0 (full recap: `claude/season2-day1-recap.md`).
Spam God6450's line across the 3 games: 4 goals, 3 assists, 1 save, 9 shots, 1,042 total score,
44.4% shooting, 1 demo inflicted, 1 taken. Game 2 was his standout — a 3-goal game, his best
individual performance of the series.

This is the first real Season 2 data point on the open question below, and it leans toward
confirming rather than complicating the Season 1 read: a hot, efficient scoring game (Game 2's
hat trick in particular) is exactly the kind of burst his 411.71-avg-points TTT sample predicted.
Still just one match day against one opponent, so not proof, but it's a genuine signal in the
predicted direction rather than a regression.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Any read on whether that 7-game stretch was a real signal or a small-sample outlier (e.g.,
  weak opposition, favorable matchups before TTT was removed)? Match Day 1's Game 2 hat trick is
  an early point in favor of "real signal," pending a larger Season 2 sample.
- On-field role and mechanical notes.
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-09-02**: Added Season 2 Match Day 1 (4G/3A/1 save, including a Game 2 hat trick, in a
  3-0 sweep of California Gurls), per Jacob's standing rule to fold match-day recap analysis into
  player profiles.
