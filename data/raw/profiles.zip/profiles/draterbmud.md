# drateRbmud

Bucky Irving FC (S2), non-captain. Season 1: rostered on Tommy Dead (TD) under captain NO
LIGHT. See `claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on Tommy Dead alongside captain NO LIGHT and Bl4ze Th3 MaN. TD did not
  reach the Season 1 Final.
- Season 2: bought by DrewAJC (Bucky Irving FC) for $7,000. He's the only Tommy Dead alum on
  a Season 2 roster — neither NO LIGHT nor Bl4ze Th3 MaN returned.

## Season 1 stats (RPL_Master_Tracker)

21 games played. 18 goals, 8 assists, 20 saves, 44 shots, 6,437 total points.
Per game: 0.86 goals, 0.38 assists, 0.95 saves, 2.10 shots, 306.52 avg points.
Rank: Diamond I (shared tier with Aowtty). Season-end Player Value: $4,168 (Base Value $3,963,
+$205 modifier, +6.8% Vs Rank Baseline).

## What the numbers say

A solid, modestly-above-tier-average performer — his +6.8% Vs Rank Baseline is the exact mirror
of Aowtty's -6.8% in the same two-player Diamond I tier, so read it as "somewhat ahead of Aowtty"
within that shared comparison, not a huge standout in absolute terms. Balanced scoring/saves
profile without a specific standout category. DrewAJC paid $7,000 — a meaningful premium (about
68%) over his $4,168 model value.

## Season 2 — Match Day 1 (2026-09-02)

Series: Bucky Irving FC lost to Fortnite Flick FC, 1–2 (full recap: `claude/season2-day1-recap.md`).
drateRbmud's line across the 3 games: 4 goals, 0 assists, 2 saves, 9 shots, 973 total score, 44.4%
shooting, 1 demo inflicted, 0 taken. He led Bucky Irving FC in scoring for the series (2 goals in
each of Games 2 and 3) and was clearly the team's primary offensive threat, ahead of Blockymalrd's
2 goals and DrewAJC's 0.

That's the first real evidence for the "premium price" open question below — DrewAJC's $7,000 buy
(68% over model value) got the series' most productive Bucky Irving scorer, even in a losing
series. Worth tracking whether that continues once the sample grows past one match day.

## Open — meta-game / meta-analysis (Jacob to fill in)

- As the only Tommy Dead alum returning, does he carry any of that team's identity/playstyle
  into Bucky Irving FC, or is this a clean slate?
- On-field role and mechanical notes.
- Why the premium price from DrewAJC — history, a specific read on his game, or auction dynamics?
  Match Day 1 (team-leading 4 goals) is an early sign the premium may be earning itself back.
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-08-28 (correction)**: TD's full name was incorrectly written as "Turtle Dynasty" —
  Jacob confirmed it's actually **Tommy Dead**. Fixed throughout.
- **2026-09-02**: Added Season 2 Match Day 1 (4G/0A/2 saves, team-leading scorer in a 1-2 series
  loss to Fortnite Flick FC), per Jacob's standing rule to fold match-day recap analysis into
  player profiles.
