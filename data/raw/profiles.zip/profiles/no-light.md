# NO LIGHT

Season 1: captain of Tommy Dead (TD). **Did not return for Season 2** — not on any Season 2
roster or in the draft pool. This profile exists as a historical record so there's a basis to
work from if he ever comes back. See `claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: captain of Tommy Dead, alongside drateRbmud and Bl4ze Th3 MaN. TD did not reach
  the Season 1 Final (999 vs. Lawson State).
- Not in the Season 2 "SEASON 2 DRAFT" pool sheet or on any Season 2 roster as of the 2026-08-28
  draft. drateRbmud is the only Tommy Dead alum who returned.

## Season 1 stats (RPL_Master_Tracker)

21 games played. 13 goals, 15 assists, 43 saves, 48 shots, 7,940 total points.
Per game: 0.62 goals, 0.71 assists, 2.05 saves (highest in the league), 2.29 shots, 378.10 avg
points.
Rank: Diamond II (shared tier with Bl4zeDaddy, Blockymalrd, and Misnfrmd — 4 players). Season-end
Player Value: $7,673 (Base Value $7,018, +$655 modifier, +21.8% Vs Rank Baseline — the largest
positive modifier of any Season 1 player, edging out Bl4zeDaddy's +13.5% in the same tier).
Won Golden Gloves (highest Avg Saves in the league, 2.05/game).

## What the numbers say

The league's clearest defensive standout — highest save rate of anyone in Season 1 by a real
margin (next closest was Bl4zeDaddy/TLBoryczka at 1.50), paired with a genuinely strong assist
rate (0.71/game, 3rd-best in the league) and modest goal-scoring. That's a last-man/support
defender who also creates offense through distribution rather than finishing himself — a
different shape than any of the returning Diamond II players. His +21.8% Vs Rank Baseline is the
single largest rank-relative overperformance recorded in Season 1, ahead of even Bl4zeDaddy's
standout number in the same tier.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Why didn't he return for Season 2 — same category of question as zPylo (done with RPL, timing,
  other reasons)?
- Any story behind Tommy Dead not reaching the Final despite a captain with the league's best
  defensive numbers?
- On-field role and mechanical notes beyond the stat line.
- Personality/reputation/leadership notes as TD's captain.

## Season log

- **2026-08-28**: Profile created as a historical/legacy record. Season 1 stats pulled from
  RPL_Master_Tracker via the Google Drive connector. Not on a Season 2 roster.
- **2026-08-28 (correction)**: TD's full name was incorrectly written as "Turtle Dynasty" —
  Jacob confirmed it's actually **Tommy Dead**. Fixed throughout.
