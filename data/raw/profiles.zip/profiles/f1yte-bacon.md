# F1yTe Bacon

Captain, California Gurls (S2). New to RPL — no Season 1 history. See
`claude/player-profiles-about.md` for methodology.

## Identity

- New to RPL for Season 2. Auto-drafted as captain of California Gurls at his own Player Value,
  $8,655 — cap money already deducted at auction time (see the discrepancy note in
  `claude/season2-format-and-rules.md`: an earlier project draft had wrongly listed Killua as this
  captain slot; the live draft sheet confirmed F1yTe Bacon).

## Season 2 — Match Day 1 (2026-09-02)

Series: California Gurls lost to Own Goal FC, 0–3 (full recap: `claude/season2-day1-recap.md`).
F1yTe Bacon's line across the 3 games: 2 goals, 2 assists, 5 saves, 6 shots, 1,124 total score,
33.3% shooting, 0 demos inflicted, 3 taken.

He was quietly California Gurls' best individual performer in a sweep loss — present in all three
games (334, 452, 338 score) without a single quiet outing, and the only CG player to register both
goals and multiple assists across the series. As a first-time captain, his own production held up
even as the team went 0–3; the losing series looks more like a team-wide territorial/resource
deficit (see the recap's team section — CG had the league's least attacking-third time and most
time stuck at 0 boost) than an individual problem with his own game. First RPL appearance, so no
prior baseline exists yet.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Leadership style as a first-time captain, especially coming off an 0-3 opening series.
- On-field role and mechanical notes.
- Personality/reputation notes worth recording.
- Whether California Gurls' Day 1 struggles were opponent-specific (Own Goal FC looked like the
  league's best team on the night) or a deeper roster issue — worth revisiting after they play a
  different opponent.

## Season log

- **2026-09-02**: Profile created from Match Day 1 data (2G/2A/5 saves, California Gurls' best
  individual line in an 0-3 series loss to Own Goal FC) — first game logged for a player who had
  no prior profile. Per Jacob's standing rule to fold match-day recap analysis into player
  profiles as recaps are produced.
