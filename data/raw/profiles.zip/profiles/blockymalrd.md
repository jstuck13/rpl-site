# Blockymalrd

Bucky Irving FC (S2), non-captain. Season 1: rostered on Lawson State under captain Astro. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on Lawson State (the eventual champions) alongside captain Astro and
  TLBoryczka.
- Season 2: bought by DrewAJC (Bucky Irving FC) for $8,091.

## Season 1 stats (RPL_Master_Tracker)

24 games played. 17 goals, 14 assists, 20 saves, 51 shots, 7,472 total points.
Per game: 0.71 goals, 0.58 assists, 0.83 saves, 2.13 shots, 311.33 avg points.
Rank: Diamond II (shared tier with Bl4zeDaddy and Misnfrmd). Season-end Player Value: $3,970
(Base Value $4,128, -$158 modifier, -5.3% Vs Rank Baseline).

## What the numbers say

A solid, unspectacular Diamond II line — middle of the pack within his own rank tier. Of the
three Diamond II players on record, Bl4zeDaddy (+13.5%) clearly outperformed the tier, Misnfrmd
(-30.1%) badly underperformed it, and Blockymalrd sits in between, modestly below tier average.
Nothing in the stat line stands out as a specific strength or weakness — a dependable rotation
piece on a Season 1 championship roster, not a standout individual number.

Worth flagging: DrewAJC's $8,091 for him is more than double his Season 1 model value ($3,970),
similar in shape (though smaller in magnitude) to the Astro/Misnfrmd situation — a captain paying
a real premium over the formula's number for a known Season 1 quantity.

## Season 2 — Match Day 1 (2026-09-02)

Series: Bucky Irving FC lost to Fortnite Flick FC, 1–2 (full recap: `claude/season2-day1-recap.md`).
Blockymalrd's line across the 3 games: 2 goals, 2 assists, 2 saves, 8 shots, 819 total score, 25%
shooting, **8 demos inflicted** (a league-high for the day) and 0 taken.

The demo number stands out — 8 demos inflicted across 3 games, more than any other player on
Match Day 1, and part of a bigger-picture Bucky Irving FC pattern (the team led the league in
demos inflicted, 12-to-1, despite losing the series). His scoring (2G/2A) was solid but not a
standout by itself; the physical, disruptive game is the new data point worth tracking against
the "premium price" question below.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Why the premium price relative to model value — chemistry/history with DrewAJC or drateRbmud,
  a specific skill the box score undersells, or just market dynamics on auction night? Match Day
  1's league-high demo count is a candidate answer (a disruptive, physical style the raw
  goals/assists numbers wouldn't have shown in Season 1) — worth confirming with Jacob whether
  that's the actual read.
- On-field role and mechanical notes.
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-09-02**: Added Season 2 Match Day 1 (2G/2A/2 saves, league-high 8 demos inflicted, in a
  1-2 series loss to Fortnite Flick FC), per Jacob's standing rule to fold match-day recap
  analysis into player profiles.
