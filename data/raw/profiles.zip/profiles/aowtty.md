# Aowtty

Lawson State (S2), non-captain. Season 1: rostered on Fire Water Gang under captain zPylo. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on Fire Water Gang alongside captain zPylo and Misnfrmd.
- Season 2: bought by Astro (Lawson State) for $4,157 — reunited with former FWG teammate
  Misnfrmd on the new roster.

## Season 1 stats (RPL_Master_Tracker)

22 games played. 9 goals, 18 assists, 15 saves, 39 shots, 5,481 total points.
Per game: 0.41 goals, 0.82 assists, 0.68 saves, 1.77 shots, 249.14 avg points.
Rank: Diamond I (shared tier with drateRbmud). Season-end Player Value: $1,797 (Base Value
$2,002, -$205 modifier, -6.8% Vs Rank Baseline).

## What the numbers say

The clearest playmaker profile of any Season 1 returner: one of the lowest goal rates in the
league (0.41/game) paired with the 2nd-highest assist rate (0.82/game, just behind TLBoryczka's
0.83) — a stark, near-total inversion of a scorer like zPylo, his own Season 1 captain. Everything
about the shape of this stat line says setup player, not finisher. His -6.8% Vs Rank Baseline is
the mirror of drateRbmud's +6.8% in their shared Diamond I tier — read as "somewhat behind
drateRbmud" within that comparison rather than a broad weakness, especially since low-volume
scorers can look worse on a pure Avg Points metric that doesn't fully credit assists.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Is the playmaker read accurate to how people who've played with him would describe his game?
- Mechanical strengths — is he more of a boost-conscious support player, a rotator, or does the
  low shot volume (1.77/game, among the lowest in the league) reflect something about his
  positioning/role specifically?
- Now reunited with Misnfrmd on Lawson State — any history there worth noting?
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
