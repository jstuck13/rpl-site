# Astro

Captain, Lawson State (S1 and S2). See `claude/player-profiles-about.md` for how these profiles
work and where the data comes from.

## Identity

- Season 1: captain of Lawson State (LS), alongside TLBoryczka and Blockymalrd. LS won the
  Season 1 championship (the Final was 999 vs. LS).
- Season 2: auto-drafted back as Lawson State's captain at his own Player Value ($9,269). Built
  the roster out with Aowtty (Fire Water Gang alum, $4,157) and Misnfrmd (Fire Water Gang alum,
  $10,317) — LS spent its entire $23,743 cap down to $0, the only team to do so.

## Season 1 stats (RPL_Master_Tracker)

27 games played. 31 goals, 13 assists, 41 saves, 89 shots, 11,428 total points.
Per game: 1.15 goals, 0.48 assists, 1.52 saves, 3.30 shots, 423.26 avg points.
Rank: Champion I. Season-end Player Value: $9,269 (Base Value $9,228 + $41 modifier).

League context: 423.26 avg points was 2nd-highest in RPL Season 1, behind only zPylo (439.05).
Won Golden Boot (31 goals, most in the league). His 3.30 shots/game was 2nd-highest behind zPylo's
4.55. Goal conversion (31 goals / 89 shots ≈ 35%) was notably efficient for that shot volume —
see the Astro-vs-zPylo comparison in `players/zpylo.md`.

## What the numbers say

A high-volume, high-efficiency finisher first — the shot count and goal total are both
top-of-league, and the conversion rate says he wasn't just shooting on volume, he was picking
good looks. Save numbers (1.52/game) are solidly mid-to-upper pack, so he wasn't offense-only.
Assist rate (0.48/game) trails several other top players (TLBoryczka 0.83, Aowtty 0.82, NO LIGHT
0.71) — the stat line reads as scorer/finisher more than primary playmaker. His Vs Rank Baseline
modifier (+1.4%, +$41) looks unremarkable but the comparison group was just himself and madlabs
(Champion I, n=2 players) — not a meaningful signal either way, small-sample artifact rather than
a real read on him relative to peers.

Net: statistically the #2 player in Season 1 behind zPylo, and unlike zPylo, his team actually won
the title. That combination (elite production + championship result) is the strongest asset in
his profile.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Actual on-field role: aggressive first-man striker, disciplined rotator, flexes depending on
  teammate?
- Mechanical signature — aerial-heavy, flicks/ceiling shots, known kickoff, more grounded/
  positional?
- Performance under pressure — closer or does he tighten up in tight series? Any specific
  clutch/choke moments from Season 1 worth recording?
- As captain, what's he like to play under — vocal shot-caller, leads by example, hands-off?
- Why Misnfrmd, specifically, at $10,317 (more than Astro's own value) despite Misnfrmd's
  Season 1 line being the weakest full-season returner stat line in the league? History between
  them, a read on his game the model can't see, or a bidding war that got away?
- Personality/reputation notes — nickname, how other players talk about him, rivalries.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-08-28 (correction)**: Misnfrmd's Season 1 team was misstated as "Turtle Dynasty alum" —
  he actually played on Fire Water Gang (with zPylo and Aowtty), per `players/misnfrmd.md`. Fixed.
