# DrewAJC

Captain/manager, Bucky Irving FC (S2). Season 1: rostered on 999 under captain madlabs. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on 999 alongside captain madlabs and Bl4zeDaddy.
- Season 2: auto-drafted as captain of his own team at his own Player Value ($3,063) — by far the
  cheapest captain of the six (the next-cheapest, Bl4zeDaddy, was more than double at $6,736).
  Team was bid on and won at auction under the name "Fire Water Gang," renamed to **Bucky Irving
  FC** after the draft completed. Built the roster entirely from Season 1 veterans: Blockymalrd
  ($8,091, Lawson State alum) and drateRbmud ($7,000, Tommy Dead alum) — the only Season 2
  team with zero rookies. $5,589 of the $23,743 cap left unspent, 2nd-most in the league.

## Season 1 stats (RPL_Master_Tracker)

17 games played (fewest of any Active-status returner). 14 goals, 3 assists, 17 saves, 45 shots,
5,084 total points.
Per game: 0.82 goals, 0.18 assists, 1.00 saves, 2.65 shots, 299.06 avg points.
Rank: Diamond III (shared tier with TLBoryczka only). Season-end Player Value: $3,063 (Base Value
$3,708, -$645 modifier, -21.5% Vs Rank Baseline).

## What the numbers say

The weakest rate-stats among the returning Active-status veterans — his 0.18 assists/game is the
lowest of anyone in the Season 1 dataset, and his -21.5% Vs Rank Baseline is a significant
underperformance. Worth noting: his rank tier (Diamond III) had exactly one other player —
TLBoryczka, whose own +21.5% is the exact mirror image of DrewAJC's -21.5%. That's not a
coincidence of two independent measurements; with only two players in the tier, one's
over-performance and the other's under-performance move symmetrically around the shared average.
So the fair read is "meaningfully below TLBoryczka" within their shared tier, not necessarily
"weak in absolute terms."

## As a Season 2 manager

Despite being the value model's lowest-rated returning captain, he built the league's only
all-veteran, zero-rookie roster — a clear bet on chemistry and known quantities over unproven
upside. Being the cheapest auto-draft also gave him more room under the cap than any other
captain going in ($20,680 before other buys), yet he still left the 2nd-most unspent — a
comparatively conservative auction relative to the room he had.

## Season 2 — Match Day 1 (2026-09-02)

Series: Bucky Irving FC lost to Fortnite Flick FC, 1–2 (full recap: `claude/season2-day1-recap.md`).
DrewAJC's line across the 3 games: 0 goals, 1 assist, 5 saves, 7 shots, 834 total score, 0.0%
shooting, 3 demos inflicted, 1 taken.

A quiet series individually — no goals on 7 shots, and the team's offense ran through drateRbmud
(4 goals) and Blockymalrd (2 goals) instead of him. That's at least directionally consistent with
the open question already on file about whether his Season 1 assist-starved line (0.18/game,
league-low) reflects a real stylistic tendency rather than a fluke of his old teammates — one
match day with 1 assist and 0 goals doesn't settle it, but it doesn't contradict it either. As a
side note, his team (Bucky Irving FC) actually won the underlying resource battle in this series —
most boost collected/stolen and a 12-1 demo edge over Fortnite Flick FC — while still losing 1-2,
so the series loss doesn't read as a Bucky Irving effort problem so much as a finishing one, and
DrewAJC's own zero-goal game is part of that picture.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Is the low assist rate a real stylistic tendency (ball-dominant, doesn't set up teammates) or
  circumstantial (played with teammates who created their own shots)? Match Day 1 (0G/1A) doesn't
  resolve this either way — still open.
- On-field role and mechanical notes.
- Why an all-veteran build for Bucky Irving FC specifically — known chemistry from prior seasons,
  or just who was left/affordable at his nomination spot (he nominated first, per the fixed
  lowest-to-highest captain order)?
- Personality/reputation, leadership style as a first-time manager.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-08-28 (correction)**: TD's full name was incorrectly written as "Turtle Dynasty" —
  Jacob confirmed it's actually **Tommy Dead**. Fixed the drateRbmud reference above.
- **2026-09-02**: Added Season 2 Match Day 1 (0G/1A/5 saves in a 1-2 series loss to Fortnite
  Flick FC), per Jacob's standing rule to fold match-day recap analysis into player profiles.
