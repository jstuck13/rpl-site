# Bl4ze Th3 MaN

Season 1: rostered on Tommy Dead (TD) under captain NO LIGHT. **Did not return for Season 2**
— not on any Season 2 roster or in the draft pool. This profile exists as a historical record so
there's a basis to work from if he ever comes back. See `claude/player-profiles-about.md` for
methodology.

## Identity

- Season 1: played on Tommy Dead alongside captain NO LIGHT and drateRbmud. TD did not reach
  the Season 1 Final.
- Not in the Season 2 draft pool or on any Season 2 roster as of the 2026-08-28 draft.

## Season 1 stats (RPL_Master_Tracker)

18 games played. 11 goals, 5 assists, 22 saves, 25 shots, 4,681 total points.
Per game: 0.61 goals, 0.28 assists, 1.22 saves, 1.39 shots, 260.06 avg points.
Rank: Platinum III — the only player at that rank in Season 1 (a singleton tier). Season-end
Player Value: $2,375 (Base Value $2,375, 0% Vs Rank Baseline by construction — a rank tier with
exactly one Active player returns a 0% baseline, since there's no peer to compare against).

## What the numbers say

A modest, below-average stat line relative to the league (260.06 avg points is on the low end of
the Active-status Season 1 pool), with the lowest shot volume among Tommy Dead's roster
(1.39/game) and the lowest assist rate of the three TD players. His Vs Rank Baseline reads exactly
0% not because he performed at a league-average level, but because Platinum III had no other
player to compare him against in Season 1 — worth remembering that this number is a construction
artifact, not a real signal either way.

Also worth noting for context: this Season 1 rank average (Platinum III, $2,375.19) became one of
the reference points used for new-player starting values going into Season 2, per
`/areas/rpl-season-1.md`'s recorded rank-average methodology.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Why didn't he return for Season 2?
- On-field role and mechanical notes — the low shot volume in particular is worth understanding
  (deferential to teammates, or genuinely limited involvement?).
- Personality/reputation notes worth recording.

## Season log

- **2026-08-28**: Profile created as a historical/legacy record. Season 1 stats pulled from
  RPL_Master_Tracker via the Google Drive connector. Not on a Season 2 roster.
- **2026-08-28 (correction)**: TD's full name was incorrectly written as "Turtle Dynasty" —
  Jacob confirmed it's actually **Tommy Dead**. Fixed throughout.
