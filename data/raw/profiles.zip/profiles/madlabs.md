# madlabs

Captain, 999 (S1 and S2). See `claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: captain of 999, alongside Bl4zeDaddy ("TTV Bl4Ze D4ddy") and DrewAJC.
- Season 2: auto-drafted back as 999's captain at his own Player Value ($8,041). Kept the 999
  name, but his old Season 1 teammates both left — Bl4zeDaddy now captains Own Goal FC, DrewAJC
  now captains Bucky Irving FC. Rebuilt around two players new to RPL: Killua ($5,590) and on
  rollr ($4,366). 999 finished the auction with the most cap space left unspent of any team,
  $5,746.

## Season 1 stats (RPL_Master_Tracker)

26 games played. 26 goals, 19 assists, 30 saves, 79 shots, 10,396 total points.
Per game: 1.00 goals, 0.73 assists, 1.15 saves, 3.04 shots, 399.85 avg points.
Rank: Champion I (paired with Astro as the league's only two Champion I players in Season 1).
Season-end Player Value: $8,041 (Base Value $8,082, -$41 modifier).

League context: 399.85 avg points was 3rd-highest in RPL Season 1, behind zPylo (439.05) and
Astro (423.26). His 0.73 assists/game was 2nd-highest in the league (behind TLBoryczka's 0.83,
just ahead of Aowtty's 0.82). Goal conversion (26/79 ≈ 33%) is efficient, in the same range as
Astro's.

## What the numbers say

The most balanced of Season 1's top tier. Where zPylo and Astro were shot-first scorers (zPylo
especially), madlabs put up the 3rd-best Avg Points in the league while also posting the
2nd-highest assist rate — high scoring output *and* high playmaking on the same stat line, rather
than one at the expense of the other. His shot volume (3.04/game) is real but lower than zPylo's
or Astro's, and his saves (1.15/game) are moderate rather than standout. Read together: less of a
pure volume shooter than his Champion I tier-mate Astro, more of an all-around contributor who
scores, sets up teammates, and still shows up defensively.

## Open — meta-game / meta-analysis (Jacob to fill in)

- On-field role — is he genuinely the all-around/playmaking presence the assist numbers suggest,
  or team-specific circumstance (e.g., played alongside shot-first teammates who needed the
  service)?
- Leadership/captaincy style, especially now rebuilding 999 around two total newcomers (Killua,
  on rollr) — what's the plan for bringing them up to speed?
- Mechanical strengths/weaknesses beyond the box score.
- Any history with Bl4zeDaddy or DrewAJC worth noting now that both former 999 teammates are
  captaining rival teams — friendly, competitive, anything there?
- Why 999 left $5,746 of cap unspent — deliberate discipline, or didn't want to get into bidding
  wars for the players available?

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
