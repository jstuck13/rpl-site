# Ugadawg50

California Gurls (S2), non-captain. Season 1: rostered on TTT under captain YoBoiHyperr. See
`claude/player-profiles-about.md` for methodology.

## Identity

- Season 1: played on TTT, the team booted from the tournament partway through the season. TTT is
  marked Inactive in the tracker; Player Value voided to N/A, raw stats retained.
- Season 2: bought by F1yTe Bacon (California Gurls) for $900 — the single cheapest price paid
  for any player in the entire Season 2 auction.

## Season 1 stats (RPL_Master_Tracker)

7 games played (TTT's season ended early). 2 goals, 2 assists, 3 saves, 13 shots, 1,000 total
points.
Per game: 0.29 goals, 0.29 assists, 0.43 saves, 1.86 shots, 142.86 avg points — by a wide margin
the weakest per-game output of any player with recorded Season 1 stats (next-lowest is
Misnfrmd's 219.82).
Status: Inactive (TTT), Player Value officially N/A/voided.

## What the numbers say

The weakest recorded Season 1 stat line in the league, from the shortest, most disrupted stint —
7 games on a team that was removed from the tournament. Unlike Spam God6450's case, there's no
tension between the price and the numbers here: the league's cheapest Season 2 buy matches its
weakest recorded stat line cleanly. The open question is upside, not explanation — whether a
fresh team and a full season change the picture, or whether TTT's roster was simply overmatched.

## Season 2 — Match Day 1 (2026-09-02)

Series: California Gurls lost to Own Goal FC, 0–3 (full recap: `claude/season2-day1-recap.md`).
Ugadawg50's line across the 3 games: 1 goal, 0 assists, 2 saves, 4 shots, 451 total score, 25%
shooting, 2 demos inflicted, 2 taken. His Game 1 score of 74 was the single lowest individual
score logged by anyone on Match Day 1.

So far, no surprises relative to the Season 1 file — the league's cheapest-ever buy posted the
softest individual series of the day on a team that lost all three games. That's one match day of
evidence layered onto a 7-game Season 1 sample, so still early, but it hasn't complicated the
"weakest recorded line in the league" read yet.

## Open — meta-game / meta-analysis (Jacob to fill in)

- Any context on TTT's situation that would explain the weak numbers beyond raw skill — team
  disarray before the removal, unfamiliarity with teammates, etc.?
- On-field role and mechanical notes.
- Personality/reputation notes worth recording.
- Whether Match Day 1's soft series was California Gurls' team-wide struggle (they lost all
  three games) or specific to him — worth revisiting once he's played against a different
  opponent.

## Season log

- **2026-08-28**: Profile created. Season 1 stats pulled from RPL_Master_Tracker via the Google
  Drive connector. Season 2 not yet underway — no S2 games logged.
- **2026-09-02**: Added Season 2 Match Day 1 (1G/0A/2 saves in an 0-3 series loss to Own Goal FC),
  per Jacob's standing rule to fold match-day recap analysis into player profiles.
